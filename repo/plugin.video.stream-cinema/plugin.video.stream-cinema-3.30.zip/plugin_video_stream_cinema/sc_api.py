# -*- coding: utf-8 -*-

from tools_archivczsk.contentprovider.exception import AddonErrorException
from tools_archivczsk.debug.http import dump_json_request
from tools_archivczsk.cache import ExpiringLRUCache
from tools_archivczsk.compat import urlparse, urlunparse, parse_qs, urlencode
import time
import json

class SCAuthException(AddonErrorException):
	pass

# ##################################################################################################################

class SC_API(object):
	def __init__(self, content_provider):
		self.cp = content_provider

		self.device_id = self.cp.load_cached_data('login').get('deviceid')

		if not self.device_id:
			# cached device ID not available - get one from settings or create new one
			self.device_id = self.cp.get_setting('deviceid') or self.create_device_id()
			self.cp.set_setting('deviceid', '')
			self.cp.update_cached_data('login', {'deviceid': self.device_id})

		self.req_session = self.cp.get_requests_session()
		self.cache = ExpiringLRUCache(30, 1800)
		self.token = None

	# ##################################################################################################################

	def save_old_token(self, token):
		old_tokens = self.cp.load_cached_data('old_tokens') or []
		old_tokens.append(token)
		self.cp.save_cached_data('old_tokens', old_tokens)

	# ##################################################################################################################

	def load_token(self):
		login_data = self.cp.load_cached_data('login').get('sc')

		if login_data == None:
			# migrate from old config file
			self.cp.log_info("SC login data not found - trying to migrate from old login data format")
			login_data = self.cp.load_cached_data('sc')
			self.cp.update_cached_data('login', {'sc': login_data})
			self.cp.save_cached_data('sc', None)

		if login_data.get('token'):
			self.cp.log_info("Auth token loaded from local cache")
			token = login_data['token']
			kr_checksum = login_data.get('kr_checksum')

			if kr_checksum and (self.cp.kraska.login_data.get('checksum') != kr_checksum):
				self.cp.log_info("SC auth token was created for another Kraska account")
				# ignore checksum error, because we don't know how server is managing tokens and we don't want to block user
				# token = None
			else:
				if login_data.get('addon_ver') != self.cp.get_addon_version():
					token2 = self.update_token(token)

					if token2 and token != token2:
						self.cp.log_info("SC auth token changed from %s to %s" % (token, token2))
						self.save_old_token(token)
						token = token2

					login_data.update({
						'token': token,
						'addon_ver': self.cp.get_addon_version()
					})
					self.cp.update_cached_data('login', {'sc': login_data})
		else:
			token = None
			self.cp.log_info("No cached auth token found")

		return token

	# ##################################################################################################################

	def update_token(self, token):
		token2 = None

		# ignore all this token update code - it looks like it can block valid tokens and we don't know why
		# try:
		# 	if self.cp.kraska.refresh_login_data() > 0:
		# 		krt = self.cp.kraska.get_token()

		# 		ret = self.call_api('/auth/token/update', data='', params={'krt': krt, 'token': token})
		# 		self.cp.log_debug("Token update response: %s" % ret)
		# 		token2 = ret.get('token')
		# except:
		# 	self.cp.log_exception()

		return token2 or token

	# ##################################################################################################################

	def save_token(self):
		if self.token:
			self.cp.update_cached_data('login', {'sc': {
				'token': self.token,
				'addon_ver': self.cp.get_addon_version(),
				'kr_checksum': self.cp.kraska.login_data.get('checksum')
			}})

	# ##################################################################################################################

	@staticmethod
	def create_device_id():
		import uuid
		return str(uuid.uuid4())


	# ##################################################################################################################

	def call_api(self, url, data=None, params=None):
		if url.startswith('/auth/'):
			token = None
		else:
			token = self.token

			if not token:
				raise SCAuthException(self.cp._("You are not authorized to access Stream Cinema service"))

		if not url.startswith("https://"):
			url = "https://stream-cinema.online/kodi" + url

		default_params = {
			'ver': '2.0',
			'uid': self.device_id,
			'lang': self.cp.dubbed_lang_list[0],
		}

		# extract params from url and add them to default_params
		u = urlparse(url)
		default_params.update(parse_qs(u.query))
		url = urlunparse((u.scheme, u.netloc, u.path, '', '', ''))

		if params:
			default_params.update(params)

		if self.cp.get_setting('item-lang-filter') == 'dubsubs':
			# zobraz len filmy s dabingom alebo titulkami
			if 'tit' not in default_params:
				default_params.update({"tit": 1})

			if 'dub' not in default_params:
				default_params.update({'dub': 1})

		elif self.cp.get_setting('item-lang-filter') == 'dub' and 'dub' not in default_params:
			default_params.update({'dub': 1}) # zobraz len dabovane filmy

		# podla nastaveni skontroluj a pripadne uprav rating pre rodicovsku kontrlu
		mr_setting = int(self.cp.get_setting('maturity-rating'))
		mr_params = default_params.get('m', 1000)
		if isinstance(mr_params, type([])):
			mr_params = mr_params[0]

		if mr_setting >= 0 and int(mr_params) > mr_setting:
			default_params.update({"m": mr_setting})

		default_params.update({'gen': 1 if self.cp.get_setting('show-genre') else 0 }) # zobraz zaner v nazve polozky

		if not params or 'HDR' not in params:
			default_params.update({'HDR': 1 if self.cp.get_setting('show-hdr') else 0 }) #zobrazit HDR ano/nie 1/0

		if not params or 'DV' not in params:
			default_params.update({'DV': 0 }) # zobrazit dolby vidion filmy ano/nie 1/0 - ziaden enigma2 prijimac toto nepodoruje

		if self.cp.get_setting('old-menu'):
			default_params.update({'old': 1 }) # zobrazit povodny typ menu

		for k in ('HDR', 'tit', 'dub'):
			# -1 means ANY for some parameters, but not for these, so remove them
			if default_params.get(k) == -1:
				del default_params[k]

		headers = {
			'User-Agent': 'ArchivCZSK/%s (plugin.video.stream-cinema/%s)' % (self.cp.get_engine_version(), self.cp.get_addon_version()),
			'X-Uuid': self.device_id
		}

		if token:
			headers['X-AUTH-TOKEN'] = token

		if data != None:
			rurl = url + '?' + urlencode(sorted(default_params.items(), key=lambda val: val[0]), True)
			resp = self.req_session.post(rurl, data=data, headers=headers)
		else:
			rurl = url + '?' + urlencode(sorted(default_params.items(), key=lambda val: val[0]), True)

			resp = self.cache.get(rurl)
			if resp:
				self.cp.log_debug("Request found in cache")
				return resp

			resp = self.req_session.get(rurl, headers=headers)
#		dump_json_request(resp)

		if resp.status_code == 200:
			try:
				resp = resp.json()
			except:
				self.cp.log_error("Failed to decode response as json:\n%s" % resp.content)
				raise AddonErrorException(self.cp._("Stream Cinema server returned in response unexpected data type. Try again later."))

			if data == None:
				ttl = 3600
				if 'system' in resp and 'TTL' in resp['system']:
					ttl = int(resp['system']['TTL'])

				self.cache.put(rurl, resp, ttl)

			return resp
		elif resp.status_code == 404 or not token:
			raise SCAuthException(self.cp._("Stream Cinema service is not available or you don't have access to it.\nServer returned HTTP error code {code} with description \"{reason}\".").format(code=resp.status_code, reason=resp.reason))
		else:
			raise AddonErrorException(self.cp._("Stream Cinema service is not available or you don't have access to it.\nServer returned HTTP error code {code} with description \"{reason}\".").format(code=resp.status_code, reason=resp.reason))

	# ##################################################################################################################

	def update_backup_token(self):
		tokens = self.load_backup_token()

		if len(tokens) > 0 and tokens[0] != self.token:
			self.cp.log_info("Updating backup auth token on kraska")
			self.save_backup_token()

			if len(tokens) > 1:
				self.cp.log_info("Removing file sc_token.txt from kraska - it is not needed anymore")
				self.cp.kraska.delete_file('sc_token.txt')

	# ##################################################################################################################

	def save_backup_token(self):
		if not self.token:
			return

		kr = self.cp.kraska

		try:
			if kr.refresh_login_data() > 0:
				self.cp.log_info("Saving auth token to kraska")
				kr.upload(self.token, 'sc.json')
		except:
			self.cp.log_exception()

	# ##################################################################################################################

	def load_backup_token(self):
		kr = self.cp.kraska
		tokens = []

		try:
			if kr.refresh_login_data() > 0:
				for name in ('sc.json', 'sc_token.txt'):
					found = kr.list_files(filter=name)

					if len(found.get('data', [])) == 1:
						for f in found.get('data', []):
							url = kr.resolve(f.get('ident'))
							if not url:
								self.cp.log_error("Failed to download backup token %s - failed to resolve data:\n%s" % (name, f))
								continue

							data = self.req_session.get(url)
							if len(data.text) == 32:
								# raw token file
								tokens.append(data.text)
								self.cp.log_info("Auth token %s loaded from kraska" % name)
							else:
								# try real json encoded file
								try:
									token = json.loads(data.text)['token']
									if len(token) == 32:
										tokens.append(token)
										self.cp.log_info("Auth token %s in alternative format loaded from kraska" % name)
								except:
									pass

					else:
						self.cp.log_info("Backup file %s with auth token not found" % name)
			else:
				self.cp.log_error("No valid subscription for kraska available - can't load backup SC login token")
		except:
			self.cp.log_exception()

		return tokens

	# ##################################################################################################################

	def check_token(self):
		try:
			self.call_api('/')
			return True
		except SCAuthException:
			return False

	# ##################################################################################################################

	def set_auth_token(self, force=False):
		if force == False and self.token:
			return

		self.token = self.load_token()

		if self.token:
			if self.check_token():
				self.cp.log_info("Local auth token is valid")
				if force:
					self.update_backup_token()

				return
			else:
				self.cp.log_error("Local auth token is invalid")
		else:
			self.cp.log_info("Local auth token not found")

		self.token = None

		# try to load token from backup
		for i, token in enumerate(self.load_backup_token()):
			self.cp.log_info("Trying token #%s from backup ..." % i)
			self.token = token
			if self.check_token():
				self.cp.log_info("Token #%s from backup is valid" % i)
				# valid token loaded from backup
				self.save_token()
				return
			else:
				self.cp.log_info("Token #%s from backup is invalid" % i)

		self.token = None
		krt = self.cp.kraska.get_token()
		auth = self.cp.load_cached_data('login').get('auth',{})

		if krt and self.cp.kraska.refresh_login_data() > 0 and (auth.get('id') != self.device_id or auth.get('krt') != krt):
			# the last chance - try to get token directly from sc server
			self.cp.log_info("Requesting auth token from SC server")
			try:
				ret = self.call_api('/auth/token', data='', params={'krt': krt})
			except:
				ret = {}
				self.cp.log_exception()

			if not ret.get('token'):
				self.cp.log_error("Error in getting auth token from SC server: %s" % ret)
				return

			self.token = ret['token']
			self.save_token()
			self.save_backup_token()
			self.cp.update_cached_data('login', {'auth': {'id': self.device_id, 'krt': krt}})

			time.sleep(5)
			if self.check_token():
				self.cp.log_info("Received valid token from SC server")
				return

			self.cp.log_error("Auth token received from SC server is invalid - you are banned or you need to wait for validation")

		self.cp.log_error("No valid auth token available")
		self.token = None

	# ##################################################################################################################
