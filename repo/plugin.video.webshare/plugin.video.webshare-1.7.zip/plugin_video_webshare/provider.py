# -*- coding: utf-8 -*-
from tools_archivczsk.contentprovider.provider import CommonContentProvider
from tools_archivczsk.contentprovider.exception import AddonErrorException, AddonInfoException
from tools_archivczsk.string_utils import _I, _C, _B, decode_html
from .webshare import Webshare, WebshareLoginFail, ResolveException
from time import time
from functools import partial

class WebshareContentProvider(CommonContentProvider):

	def __init__(self):
		CommonContentProvider.__init__(self, 'Webshare.cz')
		self.login_optional_settings_names = ('username', 'password')
		self.webshare = Webshare(self)
		self.watched = self.load_cached_data('watched')

	# ##################################################################################################################

	def login(self, silent):
		if not self.get_setting('username') or not self.get_setting('password'):
			# no username/password provided - continue with free account
			self.log_debug("No username or password provided - continuing with free account")
			return True

		try:
			self.webshare.refresh_login_data()
			login_error = None
		except WebshareLoginFail as e:
			login_error = str(e)

		if login_error != None:
			if silent:
				return False

			self.show_error(self._("Login to premium account failed: {reason}\nContinuing with free account.").format(reason=login_error), noexit=True)

		return True

	# ##################################################################################################################

	def root(self):
		try:
			self.webshare.check_premium()
		except WebshareLoginFail as e:
			self.show_info(str(e), noexit=True)

		self.add_search_dir()
		for item_id, item_data in sorted(self.watched.items(), key=lambda i: i[1]['time'], reverse=True):
			item = {
				'ident': item_id
			}
			item.update(item_data)
			menu = self.create_ctx_menu()
			menu.add_menu_item(self._("Remove from watched"), cmd=self.remove_watched_item, item_id=item_id)


			try:
				item_size = self.convert_size(item_data['size'])
			except:
				item_size = item_data.get('size') or 'N/A'

			self.add_video(item['title'] + _I(' [' + item_size + ']'), item['img'], menu=menu, cmd=self.resolve, video_title=item['title'], video_id=item['ident'], item=item)

	# ##################################################################################################################

	def convert_size(self, size_bytes):
		# convert to MB
		size = float(size_bytes) / 1024 / 1024

		if size > 1024:
			return "%.2f GB" % (size / 1024)
		else:
			return "%.2f MB" % size

	# ##################################################################################################################

	def search(self, keyword, search_id='', category=None, page=0):
		resolved_items = None
		premium_needed = False

		if search_id == 'json':
			# API for other addons - data is passed as JSON string in keyword parameter
			data = keyword
			keyword = data['keyword']
			page = data.get('page', 0)
			category = data.get('category', 'video')
			resolved_items = data.get('resolved_items')
			premium_needed = data.get('premium_needed', premium_needed)

		if premium_needed:
			try:
				self.webshare.check_premium()
			except WebshareLoginFail:
				return

		if category == None:
			category = self.get_setting('search_category')

		items, next_page = self.webshare.search(keyword, category=category, page=page)

		for item in items:
			if resolved_items != None:
				resolved_items.append({
					'title': item['title'],
					'size': item['size'],
					'size_str': self.convert_size(item['size']),
					'img': item['img'],
					'resolve_cbk': partial(self.webshare.resolve, ident=item['ident']),
				})
			else:
				self.add_video(item['title'] + _I(' [' + self.convert_size(item['size']) + ']'), item['img'], cmd=self.resolve, video_title=item['title'], video_id=item['ident'], item=item)

		if next_page and resolved_items == None:
			self.add_next(cmd=self.search, keyword=keyword, category=category, page=page+1)

	# ##################################################################################################################

	def resolve(self, video_title, video_id, item=None):
		try:
			url = self.webshare.resolve(video_id)
		except ResolveException as e:
			raise AddonErrorException(str(e))

		self.add_play(video_title, url)
		self.add_watched_item(item)

	# ##################################################################################################################

	def add_watched_item(self, item):
		self.watched[item['ident']] = {
			'title': item['title'],
			'size': item['size'],
			'img': item['img'],
			'time': int(time()),
		}

		max_watched = int(self.get_setting('max_watched'))

		if len(self.watched) > max_watched:
			for k,_ in sorted(self.watched.items(), key=lambda i: i[1]['time'], reverse=True)[max_watched:]:
				del self.watched[k]

		self.save_cached_data('watched', self.watched)

	# ##################################################################################################################

	def remove_watched_item(self, item_id):
		if item_id in self.watched:
			self.log_debug("Removing item %s from watched" % item_id)
			del self.watched[item_id]

		self.save_cached_data('watched', self.watched)
		self.show_info(self._("Item were removed. Change will be efective after next addon start."))

	# ##################################################################################################################
