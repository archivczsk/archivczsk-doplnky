# -*- coding: utf-8 -*-

class LoginException(Exception):
	pass


class AddonErrorException(Exception):
	pass


class AddonInfoException(Exception):
	pass


class AddonWarningException(Exception):
	pass

class AddonSilentExitException(Exception):
	pass
